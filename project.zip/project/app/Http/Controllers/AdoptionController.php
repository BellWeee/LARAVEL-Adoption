<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Adoption; 
Use Session;

class AdoptionController extends Controller
{
    public function create(){
        return view('insertAdoption');
    }

    public function store(){    
        $r=request();
        $insertAdoption=Adoption::create([    
            'id'=>$r->ID, 
            'name'=>$r->name, 
            'coname'=>$r->coname, 
            'address'=>$r->address, 
            'email'=>$r->email,
            'coemail'=>$r->coemail, 
            'phone'=>$r->phone, 
            'children'=>$r->children,    
            'currently'=>$r->currently,     
            'plan'=>$r->plan,     
            'city'=>$r->city, 
            'resuces'=>$r->resuces,     
            'allergic'=>$r->allergic,
            'fear'=>$r->fear,
            'smoke'=>$r->smoke,   
            'live'=>$r->live,   
            'property'=>$r->property,  
            'outside'=>$r->outside,   

            
          
        ]);
        Session::flash('success',"Product create succesful!");        
        Return redirect()->route('adoption');
    }
    public function show(){
        
        //$products=Product::all();
        $adoptions=DB::table('adoptions')
        ->select('*')
        ->get();  
        return view('adoption')->with('adoptions',$adoptions);
    }
}
