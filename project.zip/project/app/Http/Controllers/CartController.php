<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Product;
use App\User;
use App\Cart;
use Auth;
class CartController extends Controller
{
    public function add(){ 

        $r=request(); 
        $addCategory=Cart::create([    
            'name'=>$r->name, 
            'dog'=>$r->dog, 
            'profile'=>$r->profile, 
            'vaccinated'=>$r->vaccinated,
            'dewormed'=>$r->dewormed,
            'spayed'=>$r->spayed, 
            'condition'=>$r->condition,    
            'body'=>$r->body,     
            'color'=>$r->color,     
            'location'=>$r->location, 
            'posted'=>$r->posted,     
            'adoptionfee'=>$r->adoptionfee,
            'description'=>$r->description,
            'userID'=>Auth::id(), 
                        
        ]);
        Session::flash('success',"Product add succesful!");        
        Return redirect()->route('my.cart');
}

public function show(){
    $products=DB::table('products')
    ->select('products.*')
    ->get();  
       
    $carts=DB::table('carts')
    ->leftjoin('carts.*')
    ->select('*')
    ->get();
    //->paginate(3);       
    return view('showcart')->with('carts',$carts);
}
public function delete($id){
   
    $carts =myCart::find($id);
    $carts->delete();
    return redirect()->route('my.cart');
}

}