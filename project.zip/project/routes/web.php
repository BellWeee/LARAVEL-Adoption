<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/cs', function () {
    return view('contact');
});


Route::get('/insertAdoption',[
    'uses'=>'AdoptionController@create', 
    'as'=>'adoption'
]);

Route::post('insertAdoption/store',[  // define your self
    'uses'=>'AdoptionController@store',
    'as'=>'insertAdoption.store'    // check the charactor when you copy paste from PPT
]);


Route::get('/insertVolunteer',[
    'uses'=>'VolunteerController@create', 
    'as'=>'volunteer'
]);
Route::post('insertVolunteer/store',[  // define your self
    'uses'=>'VolunteerController@store',
    'as'=>'insertVolunteer.store'    // check the charactor when you copy paste from PPT
]);
Route::get('Volunteer',[
    'uses'=>'VolunteerController@show', 
    'as'=>'show.volunteer'
]);


Route::get('/insertProduct',[
    'uses'=>'ProductController@create',
    'as'=>'product'
]);

Route::post('addProduct/store',[  // define your self
    'uses'=>'ProductController@store',
    'as'=>'addProduct.store'    // check the charactor when you copy paste from PPT
]);

Route::get('/insertComment',[
    'uses'=>'CommentController@create', 
    'as'=>'Comment'
]);


Route::post('insertComment/store',[  // define your self
    'uses'=>'CommentController@store',
    'as'=>'insertComment.store'    // check the charactor when you copy paste from PPT
]);

Route::get('viewComment',[
    'uses'=>'CommentController@show', 
    'as'=>'show.comment'
]);






Route::get('/allproduct',[
    'uses'=>'ProductController@show', 
    'as'=>'all.product'
]);

Route::get('/allproduct/delete/{id}',[
    'uses'=>'ProductController@delete', 
    'as'=>'delete.product'
]);

Route::get('/editproduct/{id}',[
    'uses'=>'ProductController@edit', 
    'as'=>'edit.product'
]);


Route::post('updateproduct', [
    'uses'=>'ProductController@update',
    'as' => 'update.product'
]);

Route::post('searchproduct', [
    'uses'=>'ProductController@search',
    'as' => 'search.product'
]);


Route::get('viewProduct',[
    'uses'=>'ProductController@view', 
    'as'=>'product'
]);


Route::get('/productDetail/{id}',[
    'uses'=>'ProductController@viewProduct', 
    'as'=>'productDetail.product'
]);

Route::post('/addToCart',[
    'uses'=>'CartController@add',
    'as'=>'add.to.cart'
]);

Route::get('/   ',[
    'uses'=>'CartController@show', 
    'as'=>'my.cart'
]);
Route::get('/myCart/delete/{id}',[
    'uses'=>'CartController@delete', 
    'as'=>'delete.cart'
]);

Route::post('/createorder',[
    'uses'=>'OrderController@add',
    'as'=>'create.order'
]);

Route::get('/myorder',[
    'uses'=>'OrderController@show',
    'as'=>'my.order'
]);


Route::get('/myorder/delete/{id}',[
    'uses'=>'OrderController@delete', 
    'as'=>'delete.order'
]);



// route for processing payment
Route::post('paypal', 'PaymentController@payWithpaypal');
// route for check status of the payment
Route::get('status', 'PaymentController@getPaymentStatus');

Auth::routes(); 

Route::get('/home', 'HomeController@index')->name('home');



